this is the readme flie.
welcone!!

it is fightingGame 1.17.2

i made the first 7 characters.
thepromanager made 7 more.
sme aothers too.

All classes have 4 attacks +ult

CONTROSL: XCVB UIOP to attack. down arrow for ult. (Idk about controller it works ok)

you can press 1 or 2 for ai and thingw.
Also you can change controls in the code or chamge fps if you are noob or pro.

its avery good game.(gg)




Official steam release! Compiled version! 
https://ynjoscobi2.itch.io/fighting-game
(actually worse)
